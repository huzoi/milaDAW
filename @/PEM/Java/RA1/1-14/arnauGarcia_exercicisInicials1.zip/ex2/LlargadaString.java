public class LlargadaString {
    public static void main(String[] args) {
        String nom = "Arnau";
        System.out.println(nom.length());
    }
}