public class Multiplicacions {
    public static void main(String[] args) {
        System.out.println("\nTaula de multiplicar del 5: \n");
        for (int i = 1; i <= 10; i++) {
            System.out.println("5 x " + i + " = " + (5 * i));
        }
        System.out.println();
    }
}