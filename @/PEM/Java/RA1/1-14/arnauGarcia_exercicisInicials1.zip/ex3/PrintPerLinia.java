public class PrintPerLinia {
    public static void main(String[] args) {
        String nom = "Arnau";
        for (int i = 0; i < nom.length(); i++) {
            System.out.println(nom.charAt(i));
        }
    }
}