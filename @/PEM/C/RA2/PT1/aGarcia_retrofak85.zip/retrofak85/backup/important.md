El programa generará automàticament els arxius .dat quan els necessiti.

però per si de càs, en aquesta carpeta es troben copies "netes" d'aquests arxius per sobreescriure'ls en casos d'error o corrupció.

M'he assegurat de que aquesta versió de "main.c" funcioni correctament, i ha sigut la versió "segura" mentre he anat tirant de prova i error amb la versió d'aquest arxiu present a la carpeta arrel del programa durant l'exercici 2.