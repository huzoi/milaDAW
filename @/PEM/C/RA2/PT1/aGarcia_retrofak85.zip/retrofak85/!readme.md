RETROFAK 85

Es recomana l'eliminació dels arxius .dat després de cada execució (el programa els regenerará de nou) per evitar errors o casos de corrupció.