//Primer he provat a fer el programa a la meva manera i va quedar aix�.
/*

#include <stdio.h>

void main()
{
int edat

printf ("Quants anys tens?)
scanf ("%d%, &edat)

if (edat >18 true) printf ("Ets major d'edat!");

if (edat >18 false) printf ("Ets menor d'edat!!!!");

getch ();

{

*/

//Obviament no em va funcionar, aix� que vaig buscar c�m funcionaba la funci� 'if', l'havia escrit malament, per� tot i aixo, em vaig sorprendre c�m sense tenir-ne idea m'hi vaig apropar.


#include <stdio.h>


void main()

    {

    int edat;

    printf ("Quants anys tens???");
    scanf ("%d", &edat);

    if (edat >= 18)
      {
        printf ("Ets major d'edat! ja pots anar a la preso");
      }

    if (edat <= 18)
      {
        printf ("Ets menor d'edat! Ves a casa a mirar el pocoyo");
      }

    getch();

    }
