
#include <stdio.h>

int main()
{

   char lletra;
   char majus;
   char minus;

   // Es demana la lletra.
   printf("Introdueix una lletra: ");

   // Revisa que s'hagi introduit una lletra, i en cas de que aix� sigui, es tenca el programa.
  if (scanf("%c", &lletra) != 1)
    {
    printf("No s'ha introdu�t una lletra. El programa es tencar� en 3 segons.\n");

    return 3;
    }

  if (lletra != 'a')
    {
    printf("Lletra anterior: %c\n", lletra - 1);
    }

  if (lletra != 'z')
    {
    printf("Lletra posterior: %c\n", lletra + 1);
    }

    printf("Lletra majuscula: %c\n", lletra - 32);

    // No he aconseguit descobrir com filtrar si la lletra es maj�scula o min�scula, doncs, nom�s puc fer-ho amb la min�scula.

    return 0;

}
